<?php

class Conn {
public static $dbhost = "localhost:3306";
public static $dbuser = "root";
public static $dbpass = "";
public static $dbname = "beacon";
}

?>