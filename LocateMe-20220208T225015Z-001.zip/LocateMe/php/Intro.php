<html>
<head> yo </head>
<body>
<?php echo "yo yo"; ?>
</body>
</html>