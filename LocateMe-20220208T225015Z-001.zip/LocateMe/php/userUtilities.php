<?php

require("Conn.php");
require("MySQLDao.php");

$pname = htmlentities($_POST["pname"]);
$returnValue = array();

$dao = new MySQLDao();
$dao->openConnection();

$userDetails = $dao->getMessageFromProfessor($pname);
$returnValue["status"] = $userDetails[0];
$returnValue["message"] = " ";
echo json_encode($returnValue);

?>
